package Folder;




import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;


@Controller
public class ControllerDemo 

{
	
	
	
	
	
	// this will handle all type of request method do get and do post also
	
	@RequestMapping("/")
	public String main()
	{
		
		
		
		System.out.println("1");
		return "main-menu";
	}
	// this will handle request to specific ShowForm
	
	// important note: here hibernate jar are not added with spring so add hibernate and spring jar in lib folder in WEF
	
	@RequestMapping("/register")
public String showPage(Model m)
{
		System.out.println("\n in register");
	Student s=new Student() ;
	m.addAttribute("student", s);
		
		
	return "Register";
}
	
	
	@RequestMapping("/store")
	public String Store(@ModelAttribute("student")Student s)
	{
		System.out.println("in store");
		
		
		if(!(s.getFirstname().equals("")))
		{
			System.out.println("in first if loop");
			if(!(s.getLastname().equals("")))
			{
				System.out.println("in 2 if loop");
				
			SessionFactory f= new Configuration().configure("hibernate.cfg.xml").addAnnotatedClass(Student.class).buildSessionFactory();
				Session session= f.getCurrentSession();
				
				
				session.beginTransaction();
				session.save(s);
		        session.getTransaction().commit();
		        session.close();
				f.close();
				return "Valid";
			}
			
		}
		return "Invalid";
		
		
		
	}
	@RequestMapping("/check")
	public String check(@ModelAttribute ("student")Student s )
	{
		
		SessionFactory f= new Configuration().configure("hibernate.cfg.xml").addAnnotatedClass(Student.class).buildSessionFactory();
		Session session= f.getCurrentSession();
		
	
		session.beginTransaction();
		
		@SuppressWarnings("unchecked")
		List<Student> list= session.createQuery("from Student").getResultList();
		
		for(Student stu:list)
		{
			if(stu.getFirstname().equals(s.getFirstname()))
			{
				System.out.println(stu);
				return "Check";
				
			}
			
			
		}
		
		 session.getTransaction().commit();
	        session.close();
			f.close();
	        return "Fail";
		
		
		
		
		
		
		
		
	}
	
	@RequestMapping("/login")
	public String show(Model m)
	{
			System.out.println("\n in register");
		Student s=new Student() ;
		m.addAttribute("student", s);
			
			
		return "Login";
	}

	
}
